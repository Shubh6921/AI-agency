# Preset site export

Template: auto-machines

## Quick deploy (pre-built)
Upload this folder — index.html loads your copy/theme via draftly-custom/.

## Rebuild from source
```bash
cd auto-machines
npm install
npm run build
```
Then deploy the dist output and keep the draftly-custom/ folder alongside index.html.